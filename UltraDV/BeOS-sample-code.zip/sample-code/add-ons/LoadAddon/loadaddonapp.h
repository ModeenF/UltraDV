//*******************************
//	loadaddonapp.h
//*******************************
/*
	Copyright 1999, Be Incorporated.   All Rights Reserved.
	This file may be used under the terms of the Be Sample Code License.
*/

#ifndef LOAD_ADDON_APP_H
#define LOAD_ADDON_APP_H

#include <Application.h>

class LoadAddOnApp : public BApplication
{
	public:
		LoadAddOnApp();
};

#endif