/* StringFilterProtocol.h */

/*
	Copyright 1999, Be Incorporated.   All Rights Reserved.
	This file may be used under the terms of the Be Sample Code License.
*/

#ifndef STRING_FILTER_PROTOCOL_H
#define STRING_FILTER_PROTOCOL_H

const uint32 OPCODES =	'opcd';
const uint32 FILTER =	'filt';

#endif

