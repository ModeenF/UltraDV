/*
	dugSlider.h
*/

/*
	Copyright 1999, Be Incorporated.   All Rights Reserved.
	This file may be used under the terms of the Be Sample Code License.
*/

#ifndef DUG_SLIDER_H
#define DUG_SLIDER_H

#ifndef _SLIDER_H
#include <Slider.h>
#endif

class dugSlider : public BSlider
{
public:
				dugSlider(BRect frame); 
};

#endif //DUG_SLIDER_H
