/*
	dugApp.h
*/

/*
	Copyright 1999, Be Incorporated.   All Rights Reserved.
	This file may be used under the terms of the Be Sample Code License.
*/

#ifndef DUG_APP_H
#define DUG_APP_H

#ifndef _APPLICATION_H
#include <Application.h>
#endif

class dugApp : public BApplication 
{
public:
	dugApp();
};

#endif //DUG_APP_H
