/*
	ScriptWorld.h
	
	Copyright 1999, Be Incorporated.   All Rights Reserved.
	This file may be used under the terms of the Be Sample Code License.
*/

#ifndef SCRIPT_WORLD_H
#define SCRIPT_WORLD_H

#ifndef _APPLICATION_H
#include <Application.h>
#endif

class ScriptApplication : public BApplication 
{
public:
	ScriptApplication();
};

#endif //SCRIPT_WORLD_H
