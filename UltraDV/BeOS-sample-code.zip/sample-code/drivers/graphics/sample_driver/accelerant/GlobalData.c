/*
	Copyright 1999, Be Incorporated.   All Rights Reserved.
	This file may be used under the terms of the Be Sample Code License.
*/

#include "GlobalData.h"

int fd;
shared_info *si;
area_id shared_info_area;
vuint32 *regs;
area_id	regs_area;
display_mode *my_mode_list;
area_id	my_mode_list_area;
int accelerantIsClone;
