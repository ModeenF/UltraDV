/*
	
	HelloWorld.h

*/
/*
	Copyright 1999, Be Incorporated.   All Rights Reserved.
	This file may be used under the terms of the Be Sample Code License.
*/

#ifndef HELLO_WORLD_H
#define HELLO_WORLD_H

#ifndef _APPLICATION_H
#include <Application.h>
#endif

class HelloApplication : public BApplication 
{
public:
	HelloApplication();
};

#endif //HELLO_WORLD_H
