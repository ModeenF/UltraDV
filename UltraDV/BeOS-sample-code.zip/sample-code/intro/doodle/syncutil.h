/*
	Copyright 1999, Be Incorporated.   All Rights Reserved.
	This file may be used under the terms of the Be Sample Code License.
*/

#ifndef _syncutil_h
#define _syncutil_h

status_t WaitForDelete(sem_id blocker);

#endif /* _syncutil_h */