/*
	Copyright 1999, Be Incorporated.   All Rights Reserved.
	This file may be used under the terms of the Be Sample Code License.
*/

#ifndef _drawutils_h
#define _drawutils_h

void Stroke3DBox(BView* v, BRect r);

#endif /* _drawutils_h */
