MenuWorld

This is an application which demostrates customizing menus in the Interface Kit. It ties in with the newsletter article "Mucking With Menus," located at:

http://www.be.com/aboutbe/benewsletter/volume_II/Issue30.html#Workshop

See the About box... for directions on using MenuWorld, and the newsletter article for other salient points.

-- Owen Smith, 29-Jul-98
