//--------------------------------------------------------------------
//	
//	stddlg.h
//
//	Written by: Owen Smith
//	
//--------------------------------------------------------------------

/*
	Copyright 1999, Be Incorporated.   All Rights Reserved.
	This file may be used under the terms of the Be Sample Code License.
*/

#ifndef _stddlg_h
#define _stddlg_h

void ierror(const char* msg);

#endif /* _stddlg_h */