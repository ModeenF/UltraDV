//--------------------------------------------------------------------
//	
//	main.cpp
//
//	Written by: Owen Smith
//	
//--------------------------------------------------------------------

/*
	Copyright 1999, Be Incorporated.   All Rights Reserved.
	This file may be used under the terms of the Be Sample Code License.
*/

#include "MenuApp.h"

int main(void)
{	
	MenuApp app;
	app.Run();
	return B_NO_ERROR;
}


