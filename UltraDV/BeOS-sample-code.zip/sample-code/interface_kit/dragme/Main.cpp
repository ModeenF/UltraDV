/*
	Copyright 1999, Be Incorporated.   All Rights Reserved.
	This file may be used under the terms of the Be Sample Code License.
*/

#include "DragApp.h"


int
main()
{
	DragApp app("application/x-vnd.Be.hplus.dragapp");
	app.Run();
	return 0;
}
