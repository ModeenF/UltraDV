/* main.cpp */
/*
	Copyright 1999, Be Incorporated.   All Rights Reserved.
	This file may be used under the terms of the Be Sample Code License.
*/
#include "DDApp.h"

int main()
{
	DDApp App;
	App.Run();
	return B_NO_ERROR;	
}