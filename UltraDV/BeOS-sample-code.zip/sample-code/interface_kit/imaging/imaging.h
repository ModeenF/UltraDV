/*
	Copyright 1999, Be Incorporated.   All Rights Reserved.
	This file may be used under the terms of the Be Sample Code License.
*/

typedef long status_t;
typedef unsigned long uint32;

enum scale_method {
	IMG_SCALE_BILINEAR = 1
};